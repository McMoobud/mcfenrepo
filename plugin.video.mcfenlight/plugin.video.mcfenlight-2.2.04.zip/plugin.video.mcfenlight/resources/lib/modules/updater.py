# -*- coding: utf-8 -*-
# Auto-updater removed — McFenlight is self-managed

def check_for_update(*args, **kwargs):
	return False

def update_check(*args, **kwargs):
	return False

def get_changes(*args, **kwargs):
	return False

def rollback_check(*args, **kwargs):
	return False
