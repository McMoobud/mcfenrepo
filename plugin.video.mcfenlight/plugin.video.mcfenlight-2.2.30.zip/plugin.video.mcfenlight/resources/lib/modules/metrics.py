# -*- coding: utf-8 -*-
# McFen anonymous metrics — health + usage telemetry.
# Rules: durations/counts/labels only, NEVER titles or what-was-watched.
# Non-blocking, fail-silent, offline-queued. Candidate addon module — also the
# drop-in used for the laptop-Kodi test. Lives at resources/lib/modules/metrics.py.
import os, json, time, uuid, sqlite3, threading
import xbmc, xbmcvfs, xbmcaddon

try:
    import requests
    import socket
    import urllib3.util.connection as _u3c
    # LAN has no IPv6 egress; force IPv4 so requests never stalls on a v6-first attempt.
    _u3c.allowed_gai_family = lambda: socket.AF_INET
except Exception:
    requests = None

# --- config (filled for the laptop test; later: bake into a build) ---
INGEST_URL = "https://mcfen-ingest.mcserver.uk/ingest"
WRITE_KEY  = "1385312193cfec30c1b15b00ec9620305757db681fdc31caec3666ea40d2363c"
# --------------------------------------------------------------------

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
QUEUE_DB = os.path.join(PROFILE, "metrics_queue.db")
ID_FILE = os.path.join(PROFILE, "metrics_device_id")


def _log(msg):
    xbmc.log("McFen.metrics: %s" % msg, xbmc.LOGINFO)


def device_id():
    """Stable anonymous id, persisted in addon_data (survives restarts/updates)."""
    try:
        if xbmcvfs.exists(ID_FILE):
            f = xbmcvfs.File(ID_FILE)
            v = f.read().strip()
            f.close()
            if v:
                return v
        v = uuid.uuid4().hex
        f = xbmcvfs.File(ID_FILE, "w")
        f.write(v)
        f.close()
        return v
    except Exception:
        return "unknown"


def _platform():
    for name, cond in (
        ("android", "System.Platform.Android"),
        ("windows", "System.Platform.Windows"),
        ("osx", "System.Platform.OSX"),
        ("ios", "System.Platform.IOS"),
        ("linux", "System.Platform.Linux"),
    ):
        if xbmc.getCondVisibility(cond):
            return name
    return "unknown"


_TRAKT_CACHE = {"v": None}

def _trakt_user():
    # Prefer the stored username; treat legacy/invalid values as unset.
    try:
        from caches.settings_cache import get_setting
        v = get_setting("mcfenlight.trakt.user", "empty_setting")
        if v and str(v).lower() not in ("empty_setting", "true", "false", "none", ""):
            return v
    except Exception:
        pass
    # stale/invalid (e.g. migrated installs holding "true") -> resolve via API once
    if _TRAKT_CACHE["v"] is None:
        _TRAKT_CACHE["v"] = _resolve_trakt_from_api()
    return _TRAKT_CACHE["v"]

def _resolve_trakt_from_api():
    if not requests:
        return ""
    try:
        from caches.settings_cache import get_setting, set_setting
        token = get_setting("mcfenlight.trakt.token", "")
        client = get_setting("mcfenlight.trakt.client", "")
        if not token or token in ("empty_setting", "") or not client:
            return ""
        headers = {"Authorization": "Bearer " + str(token),
                   "trakt-api-version": "2", "trakt-api-key": str(client)}
        r = requests.get("https://api.trakt.tv/users/settings", headers=headers, timeout=8)
        if r.status_code == 200:
            u = (r.json().get("user", {}) or {}).get("username", "") or ""
            if u:
                try:
                    set_setting("trakt.user", u)  # self-heal the stored value
                except Exception:
                    pass
                return u
    except Exception:
        pass
    return ""


def _base():
    fn = xbmc.getInfoLabel("System.FriendlyName") or ""
    return {
        "device_id": device_id(),
        "mcfen_version": ADDON.getAddonInfo("version"),
        "kodi_version": (xbmc.getInfoLabel("System.BuildVersion") or "").split(" ")[0],
        "platform": _platform(),
        "device_model": fn,          # best-effort; friendly name usually carries the label
        "trakt_user": _trakt_user(),
        "friendly_name": fn,
    }


def _db():
    c = sqlite3.connect(QUEUE_DB, timeout=5)
    c.execute("CREATE TABLE IF NOT EXISTS q (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT)")
    return c


def enqueue(event, **extra):
    try:
        e = _base()
        e["event"] = event
        e["ts"] = int(time.time())
        e.update(extra)
        c = _db()
        c.execute("INSERT INTO q (payload) VALUES (?)", (json.dumps(e),))
        c.commit()
        c.close()
        threading.Thread(target=flush, daemon=True).start()
    except Exception as ex:
        _log("enqueue failed: %s" % ex)


def flush():
    """Send queued events; delete on success. Fail-silent (offline-safe)."""
    if not (requests and INGEST_URL and WRITE_KEY):
        return
    try:
        c = _db()
        rows = c.execute("SELECT id, payload FROM q ORDER BY id LIMIT 50").fetchall()
        if not rows:
            c.close()
            return
        events = [json.loads(p) for _, p in rows]
        r = requests.post(
            INGEST_URL, json={"events": events},
            headers={"Authorization": "Bearer " + WRITE_KEY}, timeout=10,
        )
        if r.status_code == 200:
            ids = tuple(i for i, _ in rows)
            c.execute("DELETE FROM q WHERE id IN (%s)" % ",".join("?" * len(ids)), ids)
            c.commit()
            _log("flushed %d" % len(ids))
        else:
            _log("flush http %s" % r.status_code)
        c.close()
    except Exception as ex:
        _log("flush failed: %s" % ex)


def checkin():
    """Call once on service startup (non-blocking)."""
    threading.Thread(target=lambda: enqueue("checkin"), daemon=True).start()


class MetricsPlayer(xbmc.Player):
    """Emits session_start/session_end (duration only) + playback errors."""

    def __init__(self):
        super().__init__()
        self._start = None
        self._sid = None

    def onAVStarted(self):
        self._start = time.time()
        self._sid = uuid.uuid4().hex
        enqueue("session_start", session_id=self._sid)

    def _end(self):
        if self._start:
            dur = int(time.time() - self._start)
            enqueue("session_end", session_id=self._sid, duration_s=dur)
            self._start = None
            self._sid = None

    def onPlayBackEnded(self):
        self._end()

    def onPlayBackStopped(self):
        self._end()

    def onPlayBackError(self):
        enqueue("error", error_type="playback_error")
        self._end()
