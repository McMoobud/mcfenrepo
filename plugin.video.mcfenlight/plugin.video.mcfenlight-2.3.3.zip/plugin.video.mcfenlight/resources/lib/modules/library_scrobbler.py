"""
Record Kodi-library plays (local files, Emby for Kodi) on Trakt with McFen's own Trakt login.

Kodi bumps an item's playcount (VideoLibrary.OnUpdate with playcount >= 1) when a library item is finished.
We only act on the library item that was actually just played on this device, so library syncs / bulk playcount
updates (e.g. Emby pulling watched state from the server) never post history. McFen's own streams have no
library DBID and are marked by McFen's player as before. Nothing happens unless watched status is kept on Trakt.
"""
import json
import time
from threading import Thread
import xbmc
from modules import kodi_utils

def _rpc(method, params):
	try: return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}))).get('result', {}) or {}
	except: return {}

def _log(msg):
	kodi_utils.logger('McFenlight.library_scrobble', msg)

def _mark(dbtype, dbid):
	try:
		from modules import settings, watched_status
		if settings.watched_indicators() != 1: return
		if dbtype == 'episode':
			ep = _rpc('VideoLibrary.GetEpisodeDetails', {'episodeid': dbid, 'properties': ['tvshowid', 'season', 'episode', 'showtitle']}).get('episodedetails', {})
			show = _rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': ep.get('tvshowid', -1), 'properties': ['uniqueid']}).get('tvshowdetails', {})
			ids = show.get('uniqueid') or {}
			if not (ids.get('tmdb') or ids.get('tvdb')) or not ep.get('episode'): return _log('no ids for episode %s' % dbid)
			watched_status.mark_episode({'action': 'mark_as_watched', 'tmdb_id': ids.get('tmdb'), 'tvdb_id': ids.get('tvdb') or 0, 'season': ep.get('season'),
										'episode': ep.get('episode'), 'title': ep.get('showtitle', ''), 'from_playback': 'true'})
			_log('marked %s S%sE%s on Trakt' % (ep.get('showtitle'), ep.get('season'), ep.get('episode')))
		elif dbtype == 'movie':
			mv = _rpc('VideoLibrary.GetMovieDetails', {'movieid': dbid, 'properties': ['uniqueid', 'title', 'year']}).get('moviedetails', {})
			ids = mv.get('uniqueid') or {}
			if not ids.get('tmdb'): return _log('no tmdb id for movie %s' % dbid)
			watched_status.mark_movie({'action': 'mark_as_watched', 'tmdb_id': ids.get('tmdb'), 'title': mv.get('title', ''), 'year': mv.get('year', ''),
									'from_playback': 'true'})
			_log('marked %s (%s) on Trakt' % (mv.get('title'), mv.get('year')))
	except Exception as e: _log('mark failed: %s' % e)

class LibraryScrobbler(xbmc.Player):
	def __init__(self):
		xbmc.Player.__init__(self)
		self.current, self.last = None, None

	def _rotate(self):
		if self.current: self.last = (self.current, time.time())
		self.current = None

	def onPlayBackStarted(self):
		self._rotate()  # playlist advance doesn't always fire Ended/Stopped for the previous item

	def onAVStarted(self):
		try:
			dbtype, dbid = xbmc.getInfoLabel('VideoPlayer.DBTYPE'), int(xbmc.getInfoLabel('VideoPlayer.DBID') or -1)
			self.current = (dbtype, dbid) if dbtype in ('episode', 'movie') and dbid > 0 else None
		except: self.current = None

	def onPlayBackStopped(self):
		self._rotate()

	def onPlayBackEnded(self):
		self._rotate()

	def on_library_update(self, data):
		try:
			d = json.loads(data)
			if int(d.get('playcount', 0) or 0) < 1: return
			item = d.get('item') or {}
			key = (item.get('type'), int(item.get('id', -1)))
			just_played = self.current == key or (self.last and self.last[0] == key and time.time() - self.last[1] < 300)
			if not just_played: return
			if self.last and self.last[0] == key: self.last = None  # one post per play
			Thread(target=_mark, args=key).start()
		except Exception as e: _log('update error: %s' % e)
