from caches.debrid_cache import debrid_cache
from apis.torbox_api import TorBoxAPI
from modules.kodi_utils import show_busy_dialog, hide_busy_dialog, notification, logger
from modules.settings import enabled_debrids_check

def debrid_enabled():
	return [
	i[0] for i in [('TorBox', 'tb')] if enabled_debrids_check(i[1])]

def debrid_for_ext_cache_check(enabled_debrid=None):
	# External (torrentio/mediafusion/dmm) cache pre-check only applied to Real-Debrid / AllDebrid,
	# both retired. TorBox checks cache via its own API, so this is always False now.
	return False

def manual_add_magnet_to_cloud(params):
	show_busy_dialog()
	debrid_list_modules = [('TorBox', TorBoxAPI)]
	function = [i[1] for i in debrid_list_modules if i[0] == params['provider']][0]
	result = function().create_transfer(params['magnet_url'])
	function().clear_cache()
	hide_busy_dialog()
	if result == 'failed': notification('Failed')
	else: notification('Success')

def query_local_cache(hash_list):
	return debrid_cache.get_many(hash_list) or []

def add_to_local_cache(hash_list, debrid, expires=24):
	debrid_cache.set_many(hash_list, debrid, expires)

def cached_check(hash_list, cached_hashes, debrid):
	cached_list = [i[0] for i in cached_hashes if i[1] == debrid and i[2] == 'True']
	unchecked_list = [i for i in hash_list if not any([h for h in cached_hashes if h[0] == i and h[1] == debrid])]
	return cached_list, unchecked_list

def TB_check(hash_list, cached_hashes):
	expires = 24
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'tb')
	if unchecked_hashes:
		results = TorBoxAPI().check_cache(unchecked_hashes)
		if results:
			cached_append = cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				data = results['data']
				results = [i['hash'] for i in data]
				for h in unchecked_hashes:
					cached = 'False'
					if h in results:
						cached_append(h)
						cached = 'True'
					process_append((h, cached))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
		else: process_list, expires  = [(h, 'False') for h in unchecked_hashes], 2
		add_to_local_cache(process_list, 'tb', expires)
	return cached_hashes
