"""
Global Kodi context menu (McFen: Find / McFen: Play on library/Emby items).

Two halves:
  launch()  -> runs inside the context-item script; reads the focused ListItem, resolves parent-show ids
               via JSON-RPC for episodes/seasons, then hands off to the plugin via RunPlugin (mode=mcfen_ctx.*).
  find/play -> run inside the plugin; resolve a TMDb id (tmdb -> imdb/tvdb -> title search) and open
               the McFen listing (find) or the source picker for the exact movie/episode (play).
"""
import json
from urllib.parse import urlencode, quote

PLUGIN_URL = 'plugin://plugin.video.mcfenlight/'

def _rpc(method, params):
	import xbmc
	try: return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}))).get('result', {}) or {}
	except: return {}

def _show_ids_from_library(media_type, dbid):
	details_key = {'episode': ('VideoLibrary.GetEpisodeDetails', 'episodeid', 'episodedetails'),
					'season': ('VideoLibrary.GetSeasonDetails', 'seasonid', 'seasondetails')}.get(media_type)
	if not details_key or not dbid or dbid < 1: return {}
	method, id_key, result_key = details_key
	tvshowid = _rpc(method, {id_key: dbid, 'properties': ['tvshowid']}).get(result_key, {}).get('tvshowid')
	if not tvshowid or tvshowid < 1: return {}
	show = _rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': tvshowid, 'properties': ['uniqueid', 'title', 'year']}).get('tvshowdetails', {})
	uniqueid = show.get('uniqueid', {}) or {}
	return {'tmdb': uniqueid.get('tmdb', ''), 'imdb': uniqueid.get('imdb', ''), 'tvdb': uniqueid.get('tvdb', ''),
			'showtitle': show.get('title', ''), 'year': str(show.get('year') or '')}

def launch(action):
	import sys, xbmc
	try: item = sys.listitem
	except AttributeError: return
	tag = item.getVideoInfoTag()
	media_type = tag.getMediaType() or xbmc.getInfoLabel('ListItem.DBType')
	data = {'mode': 'mcfen_ctx.%s' % action, 'media_type': media_type, 'title': tag.getTitle(), 'showtitle': tag.getTVShowTitle(),
			'year': str(tag.getYear() or ''), 'season': str(tag.getSeason()), 'episode': str(tag.getEpisode()), 'tmdb': '', 'imdb': '', 'tvdb': ''}
	if media_type in ('movie', 'tvshow'):
		# Item's own ids ARE the movie/show ids
		data.update({'tmdb': tag.getUniqueID('tmdb') or '', 'imdb': tag.getUniqueID('imdb') or tag.getIMDBNumber() or '', 'tvdb': tag.getUniqueID('tvdb') or ''})
		if media_type == 'tvshow': data['showtitle'] = data['showtitle'] or data['title']
	else:
		# Episode/season ids belong to the episode, not the show -> look the parent show up in the library
		show = _show_ids_from_library(media_type, tag.getDbId())
		data.update({k: v for k, v in show.items() if v})
		if not show: data['year'] = ''
	xbmc.executebuiltin('RunPlugin(%s?%s)' % (PLUGIN_URL, urlencode(data)))

def _pick(results, title, year, title_key, date_key):
	if not results: return None
	title, year = (title or '').lower().strip(), (year or '').strip()
	def _year(i): return (i.get(date_key) or '')[:4]
	for check in (lambda i: i.get(title_key, '').lower() == title and _year(i) == year,
				lambda i: _year(i) == year and year,
				lambda i: i.get(title_key, '').lower() == title):
		match = next((i for i in results if check(i)), None)
		if match: return match
	return results[0]

def _resolve_movie(params):
	from apis import tmdb_api
	from modules.settings import tmdb_api_key
	tmdb, imdb, title, year = params.get('tmdb'), params.get('imdb', ''), params.get('title'), params.get('year')
	if tmdb: return tmdb
	api_key = tmdb_api_key()
	if imdb.startswith('tt'):
		result = tmdb_api.movie_external_id('imdb_id', imdb, api_key)
		if result: return str(result['id'])
	if not title: return None
	try: results = tmdb_api.tmdb_movies_search(quote(title), 1)['results']
	except: results = []
	match = _pick(results, title, year, 'title', 'release_date')
	return str(match['id']) if match else None

def _resolve_show(params):
	from apis import tmdb_api
	from modules.settings import tmdb_api_key
	tmdb, tvdb, imdb, title, year = params.get('tmdb'), params.get('tvdb'), params.get('imdb', ''), params.get('showtitle') or params.get('title'), params.get('year')
	if tmdb: return tmdb
	api_key = tmdb_api_key()
	for source, value in (('tvdb_id', tvdb), ('imdb_id', imdb if imdb.startswith('tt') else '')):
		if not value: continue
		result = tmdb_api.tvshow_external_id(source, value, api_key)
		if result: return str(result['id'])
	if not title: return None
	try: results = tmdb_api.tmdb_tv_search(quote(title), 1)['results']
	except: results = []
	match = _pick(results, title, year, 'name', 'first_air_date')
	return str(match['id']) if match else None

def find(params):
	from modules.kodi_utils import build_url, execute_builtin, notification
	if params.get('media_type') == 'movie':
		title = params.get('title')
		if not title: return notification('No title to search for')
		url_params = {'mode': 'build_movie_list', 'action': 'tmdb_movies_search', 'query': title, 'key_id': title, 'name': 'Search Results for %s' % title}
	else:
		tmdb_id = _resolve_show(params)
		title = params.get('showtitle') or params.get('title')
		if tmdb_id: url_params = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
		elif title: url_params = {'mode': 'build_tvshow_list', 'action': 'tmdb_tv_search', 'is_anime_list': 'false', 'query': title, 'key_id': title,
								'name': 'Search Results for %s' % title}
		else: return notification('No title to search for')
	execute_builtin('ActivateWindow(Videos,%s,return)' % build_url(url_params))

def play(params):
	from modules.kodi_utils import notification
	from modules.settings import playback_key
	media_type = params.get('media_type')
	if media_type == 'movie':
		tmdb_id = _resolve_movie(params)
		play_params = {'mode': 'playback.media', 'media_type': 'movie', 'tmdb_id': tmdb_id}
	elif media_type == 'episode':
		tmdb_id = _resolve_show(params)
		try: season, episode = int(params.get('season')), int(params.get('episode'))
		except: season, episode = -1, -1
		if season < 0 or episode < 1: return notification('Could not read season/episode')
		play_params = {'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode}
	else: return notification('Play works on movies and episodes only')
	if not tmdb_id: return notification('No match found - try Find in McFenlight')
	key = playback_key()
	play_params.update({'autoplay': 'false', key: key})
	from modules.sources import Sources
	Sources().playback_prep(play_params)
