from modules.context_menu import launch

launch('play')
