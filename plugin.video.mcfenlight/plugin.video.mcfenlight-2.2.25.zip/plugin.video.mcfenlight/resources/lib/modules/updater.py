# -*- coding: utf-8 -*-
# McFenlight self-updater — points at McMoobud/mcfenrepo (GitHub Pages)
import json
import requests
import shutil
from os import path
from caches.settings_cache import set_setting
from modules.utils import string_alphanum_to_num, unzip
from modules import kodi_utils
logger = kodi_utils.logger

repo_user = 'McMoobud'
repo_name = 'mcfenrepo'
addon_id = 'plugin.video.mcfenlight'

def get_location(insert=''):
	return 'https://%s.github.io/%s/%s/%s' % (repo_user.lower(), repo_name, addon_id, insert)

def get_versions():
	try:
		result = requests.get(get_location('mcfenlight_version'), timeout=15)
		if result.status_code != 200: return None, None
		online_version = result.text.strip()
		current_version = kodi_utils.addon_version()
		return current_version, online_version
	except: return None, None

def get_changes(online_version=None):
	try:
		if not online_version:
			current_version, online_version = get_versions()
			if not version_check(current_version, online_version): return kodi_utils.ok_dialog(heading='McFenlight Updater',
				text='You are running the current version of McFenlight.[CR][CR]There is no new version changelog to view.')
		kodi_utils.show_busy_dialog()
		result = requests.get(get_location('mcfenlight_changes'), timeout=15)
		kodi_utils.hide_busy_dialog()
		if result.status_code != 200: return kodi_utils.notification('Error', icon=kodi_utils.get_icon('downloads'))
		changes = result.text
		return kodi_utils.show_text('New Online Release (v.%s) Changelog' % online_version, text=changes, font_size='large')
	except:
		kodi_utils.hide_busy_dialog()
		return kodi_utils.notification('Error', icon=kodi_utils.get_icon('downloads'))

def version_check(current_version, online_version):
	return string_alphanum_to_num(current_version) != string_alphanum_to_num(online_version)

def _fetch_first_changelog_line(online_version):
	"""Return the first bullet point from the online changelog, stripped of Kodi tags."""
	import re
	try:
		result = requests.get(get_location('mcfenlight_changes'), timeout=15)
		if result.status_code != 200: return ''
		for line in result.text.splitlines():
			line = re.sub(r'\[/?(?:COLOR[^\]]*|B|I|CR)\]', '', line).strip()
			if line.startswith('- '):
				return line[2:]
	except: pass
	return ''

def update_check(action=4):
	if action == 3: return
	current_version, online_version = get_versions()
	if not current_version or not online_version: return
	if not version_check(current_version, online_version):
		if action == 4: return kodi_utils.ok_dialog(heading='McFenlight Updater',
			text='Installed Version: [B]%s[/B][CR]Online Version: [B]%s[/B][CR][CR][B]No Update Available[/B]' % (current_version, online_version))
		return
	if action == 2: return kodi_utils.notification('McFenlight Update Available', icon=kodi_utils.get_icon('downloads'))
	if action == 1: kodi_utils.notification('McFenlight Update Occurring', icon=kodi_utils.get_icon('downloads'))
	if action in (0, 4):
		kodi_utils.show_busy_dialog()
		first_line = _fetch_first_changelog_line(online_version)
		kodi_utils.hide_busy_dialog()
		text = '[B]v%s[/B] is available[CR][CR]%s[CR][CR]Install now?' % (online_version, first_line)
		if not kodi_utils.confirm_dialog(heading='McFenlight Update', text=text, ok_label='Update', cancel_label='Skip'):
			return
	return update_addon(online_version, action, show_after_action=False)

def rollback_check():
	current_version = get_versions()[0]
	url = 'https://api.github.com/repos/%s/%s/contents/%s' % (repo_user, repo_name, addon_id)
	kodi_utils.show_busy_dialog()
	results = requests.get(url, timeout=15)
	kodi_utils.hide_busy_dialog()
	if results.status_code != 200: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Error rolling back.[CR]Please install rollback manually')
	results = results.json()
	results = [i['name'].split('-')[1].replace('.zip', '') for i in results if addon_id in i['name'] and i['name'].endswith('.zip') \
				and not i['name'].split('-')[1].replace('.zip', '') == current_version]
	if not results: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='No previous versions found.[CR]Please install rollback manually')
	results.sort(reverse=True)
	list_items = [{'line1': item, 'icon': kodi_utils.get_icon('downloads')} for item in results]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Rollback Version'}
	rollback_version = kodi_utils.select_dialog(results, **kwargs)
	if rollback_version == None: return
	if not kodi_utils.confirm_dialog(heading='McFenlight Updater',
		text='Are you sure?[CR]Version [B]%s[/B] will overwrite your current installed version.[CR]McFenlight will set your update action to [B]OFF[/B] if rollback is successful' \
		% rollback_version): return
	update_addon(rollback_version, 5)

def update_addon(new_version, action, show_after_action=True):
	kodi_utils.close_all_dialog()
	kodi_utils.execute_builtin('ActivateWindow(Home)', True)
	kodi_utils.notification('McFenlight Performing Rollback' if action == 5 else 'McFenlight Performing Update', icon=kodi_utils.get_icon('downloads'))
	zip_name = '%s-%s.zip' % (addon_id, new_version)
	url = get_location(zip_name)
	kodi_utils.show_busy_dialog()
	result = requests.get(url, stream=True, timeout=60)
	kodi_utils.hide_busy_dialog()
	if result.status_code != 200: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Error Updating.[CR]Please install new update manually')
	zip_location = path.join(kodi_utils.translate_path('special://home/addons/packages/'), zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
	shutil.rmtree(path.join(kodi_utils.translate_path('special://home/addons/'), addon_id))
	success = unzip(zip_location, kodi_utils.translate_path('special://home/addons/'), kodi_utils.translate_path('special://home/addons/%s/' % addon_id))
	kodi_utils.delete_file(zip_location)
	if not success: return kodi_utils.ok_dialog(heading='McFenlight Updater', text='Error Updating.[CR]Please install new update manually')
	if action == 5:
		set_setting('update.action', '3')
		kodi_utils.ok_dialog(heading='McFenlight Updater', text='[CR]Success.[CR]McFenlight rolled back to version [B]%s[/B]' % new_version)
	elif action in (0, 4):
		if show_after_action:
			if kodi_utils.confirm_dialog(heading='McFenlight Updater', text='[CR]Success.[CR]McFenlight updated to version [B]%s[/B]' % new_version,
										ok_label='Changelog', cancel_label='Exit', default_control=10) != False:
				kodi_utils.show_text('Changelog', file=kodi_utils.translate_path('special://home/addons/%s/resources/text/changelog.txt' % addon_id), font_size='large')
		else:
			kodi_utils.ok_dialog(heading='McFenlight Updater', text='[CR]Success.[CR]McFenlight updated to version [B]%s[/B]' % new_version)
	kodi_utils.clear_addon_icon_texture_cache()
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()
	kodi_utils.update_kodi_addons_db()
	kodi_utils.refresh_widgets()
