"""
Record Kodi-library plays (local files, Emby for Kodi) on Trakt with McFen's own Trakt login.

Kodi bumps an item's playcount (VideoLibrary.OnUpdate with playcount >= 1) when a library item is finished.
We only act on the library item that was actually just played on this device (matched by played file path, with the
library DBID as a fallback — Emby-for-Kodi playback doesn't expose VideoPlayer.DBID), so library syncs / bulk playcount
updates (e.g. Emby pulling watched state from the server) never post history. McFen's own streams have no
library DBID and are marked by McFen's player as before. Nothing happens unless watched status is kept on Trakt.
"""
import json
import time
from threading import Thread
import xbmc
from modules import kodi_utils

def _rpc(method, params):
	try: return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}))).get('result', {}) or {}
	except: return {}

def _log(msg):
	kodi_utils.logger('McFenlight.library_scrobble', msg)

def _mark(dbtype, dbid):
	try:
		from modules import settings, watched_status
		if settings.watched_indicators() != 1: return
		if dbtype == 'episode':
			ep = _rpc('VideoLibrary.GetEpisodeDetails', {'episodeid': dbid, 'properties': ['tvshowid', 'season', 'episode', 'showtitle']}).get('episodedetails', {})
			show = _rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': ep.get('tvshowid', -1), 'properties': ['uniqueid']}).get('tvshowdetails', {})
			ids = show.get('uniqueid') or {}
			if not (ids.get('tmdb') or ids.get('tvdb')) or not ep.get('episode'): return _log('no ids for episode %s' % dbid)
			watched_status.mark_episode({'action': 'mark_as_watched', 'tmdb_id': ids.get('tmdb'), 'tvdb_id': ids.get('tvdb') or 0, 'season': ep.get('season'),
										'episode': ep.get('episode'), 'title': ep.get('showtitle', ''), 'from_playback': 'true'})
			_log('marked %s S%sE%s on Trakt' % (ep.get('showtitle'), ep.get('season'), ep.get('episode')))
		elif dbtype == 'movie':
			mv = _rpc('VideoLibrary.GetMovieDetails', {'movieid': dbid, 'properties': ['uniqueid', 'title', 'year']}).get('moviedetails', {})
			ids = mv.get('uniqueid') or {}
			if not ids.get('tmdb'): return _log('no tmdb id for movie %s' % dbid)
			watched_status.mark_movie({'action': 'mark_as_watched', 'tmdb_id': ids.get('tmdb'), 'title': mv.get('title', ''), 'year': mv.get('year', ''),
									'from_playback': 'true'})
			_log('marked %s (%s) on Trakt' % (mv.get('title'), mv.get('year')))
	except Exception as e: _log('mark failed: %s' % e)

def _library_file(dbtype, dbid):
	if dbtype == 'episode': return _rpc('VideoLibrary.GetEpisodeDetails', {'episodeid': dbid, 'properties': ['file']}).get('episodedetails', {}).get('file', '')
	if dbtype == 'movie': return _rpc('VideoLibrary.GetMovieDetails', {'movieid': dbid, 'properties': ['file']}).get('moviedetails', {}).get('file', '')
	return ''

class LibraryScrobbler(xbmc.Player):
	def __init__(self):
		xbmc.Player.__init__(self)
		self.current, self.last = None, None

	def _rotate(self):
		if self.current: self.last = (self.current, time.time())
		self.current = None

	def onPlayBackStarted(self):
		self._rotate()  # playlist advance doesn't always fire Ended/Stopped for the previous item

	def onAVStarted(self):
		try:
			try: dbid = int(xbmc.getInfoLabel('VideoPlayer.DBID') or -1)
			except: dbid = -1
			dbtype = xbmc.getInfoLabel('VideoPlayer.DBTYPE')
			try: played = self.getPlayingFile()
			except: played = ''
			# McFen's own streams never match a library file, so recording every play is harmless
			self.current = {'file': played, 'dbtype': dbtype, 'dbid': dbid}
			if dbid > 0 or played.startswith('/emby') or not played.startswith('http'): _log('playing %s dbid=%s file=%s' % (dbtype or '?', dbid, played[:90]))
		except: self.current = None

	def onPlayBackStopped(self):
		self._rotate()

	def onPlayBackEnded(self):
		self._rotate()

	def on_library_update(self, data):
		try:
			d = json.loads(data)
			if int(d.get('playcount', 0) or 0) < 1: return
			item = d.get('item') or {}
			key = (item.get('type'), int(item.get('id', -1)))
			if key[0] not in ('episode', 'movie') or key[1] < 1: return
			candidates = [c for c in (self.current, self.last[0] if self.last and time.time() - self.last[1] < 300 else None) if c]
			if not candidates: return
			lib_file = _library_file(*key)
			match = next((c for c in candidates if (lib_file and c['file'] == lib_file) or (c['dbtype'] == key[0] and c['dbid'] == key[1])), None)
			if not match: return _log('playcount update for %s %s ignored (not the item just played)' % key)
			if self.last and self.last[0] is match: self.last = None  # one post per play
			elif self.current is match: self.current = None
			_log('Kodi counted %s %s as watched - sending to Trakt' % key)
			Thread(target=_mark, args=key).start()
		except Exception as e: _log('update error: %s' % e)
